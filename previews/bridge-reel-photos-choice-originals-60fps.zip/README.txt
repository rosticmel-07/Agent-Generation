Bridge Agency — Фото є. А що обрати?

22 секунди, 9:16, справжні 60 fps. Українська озвучка та вбудовані субтитри.
bridge-reel-photos-choice-hq-60fps.mp4 — 1080 × 1920, для рекламного тесту Meta.
bridge-reel-photos-choice-master-4k-60fps.mp4 — 2160 × 3840, майстер.
Обидва MP4 збережено в ZIP без перетворення або повторного стиснення.
Контрольні суми та результати перевірок — photos-choice-export-report.json.
