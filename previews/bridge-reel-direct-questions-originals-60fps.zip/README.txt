Bridge Agency — Знову ті самі питання?

24 секунди, 9:16, справжні 60 fps. Українська озвучка та вбудовані субтитри.
bridge-reel-direct-questions-hq-60fps.mp4 — 1080 × 1920, для рекламного тесту Meta.
bridge-reel-direct-questions-master-4k-60fps.mp4 — 2160 × 3840, майстер.
Обидва MP4 збережено в ZIP без перетворення або повторного стиснення.
Контрольні суми та результати перевірок — direct-questions-export-report.json.
